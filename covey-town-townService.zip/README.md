# CoveyTownLiveWebApp
Built a live web application using Typescript, React, and SQL, to create a virtual setting where users can interact, chat, and play interactive games.
